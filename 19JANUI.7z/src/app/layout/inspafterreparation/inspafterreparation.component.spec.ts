import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InspafterreparationComponent } from './inspafterreparation.component';

describe('InspafterreparationComponent', () => {
  let component: InspafterreparationComponent;
  let fixture: ComponentFixture<InspafterreparationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InspafterreparationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InspafterreparationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
