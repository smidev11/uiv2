import { InspafterreparationModule } from './inspafterreparation.module';

describe('InspafterreparationModule', () => {
  let inspafterreparationModule: InspafterreparationModule;

  beforeEach(() => {
    inspafterreparationModule = new InspafterreparationModule();
  });

  it('should create an instance', () => {
    expect(inspafterreparationModule).toBeTruthy();
  });
});
