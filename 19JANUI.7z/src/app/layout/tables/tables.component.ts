import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { HttpClient, HttpParams } from '@angular/common/http';
import * as $ from 'jquery';
// For autosuggest
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { DELEGATE_CTOR } from '@angular/core/src/reflection/reflection_capabilities';
import { DatePipe } from '@angular/common'

@Component({
    selector: 'app-tables',
    templateUrl: './tables.component.html',
    styleUrls: ['./tables.component.scss'],
    animations: [routerTransition()]
})
export class TablesComponent implements OnInit {
    // For autosuggest start
    EMPLIST=["ATTT","BBBs"];
    jobList=[];
    public model: any;
    jobId:String;
    TCNumberList = []
    clientNameList=[]
    selected_tc_no;
    selected_client;
    error:boolean;
    errorMessage;
    sucess:boolean;
    sucessMessage;
    batchId:string
    batchIdList:any=[]
    CONSUMABLE_SUPPLIER_DEG:any=[]
    searchTC = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term => term.length < 1 ? []
        : this.TCNumberList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )

    search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term => term.length < 1 ? []
        : this.EMPLIST.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )


    searchBatch = (text$: Observable<string>) =>
        text$.pipe(
        debounceTime(200),
        distinctUntilChanged(),
        map(term => term.length < 1 ? []
        : this.batchIdList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
        )

    searchSupplier = (text$: Observable<string>) =>
    text$.pipe(
    debounceTime(200),
    distinctUntilChanged(),
    map(term => term.length < 1 ? []
    : this.CONSUMABLE_SUPPLIER_DEG.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )

    
// For autosuggest end
    editField: string;
    personList: Array<any> = [];

    TableData: any = [];
    SelectedRowId: any = '';
    ShowEditTable :boolean = false;

    updateList_old(id: number, property: string, event: any) {
      
        this.editField  = event.target.textContent;
        
        if(property == "endtime"){
           debugger
           var tempstarttime = this.personList[id]['stime']
           var tempendtime = event.target.textContent;
  
           var stime = this.getMinutes(tempstarttime);
           var etime = this.getMinutes(tempendtime)
           var val = (Number(etime) - Number(stime))
           var operational_time = " ";
           
           if(val < 0){
              operational_time = " "
           }else{
              
               if(val > 60){
                   var totalmin = val % 60;
                   var totalhr = (val/60);
                   var strtotalhr = totalhr+"";
                   if(strtotalhr.includes(".")){
                      strtotalhr = strtotalhr.split(".")[0]
                   }
                   operational_time = strtotalhr +" hr "+totalmin+" min"
                   
               }else{
            	operational_time = val+" min"
          }
           }
           this.personList[id]["operationtime"] = operational_time;
  
        }
        if(property == "methoddegreasing"){
          if(Number(this.editField) > 4){
              alert("Enter the value between 1 to 4")
              return false
          }
        }else{
          console.log("remove no match")  
        }
  
        this.personList[id][property] = event.target.textContent;
        
        console.log(this.personList)
        
      }

     updateList(id: number,property: string,event: any) {
      
      
      
      if(property == "endtime"){
         debugger
         var tempstarttime = this.personList[id]['stime']
         var tempendtime = this.personList[id]['endtime']

         var stime = this.getMinutes(tempstarttime);
         var etime = this.getMinutes(tempendtime)
         var val = (Number(etime) - Number(stime))
         var operational_time = " ";
         
         if(val < 0){
            operational_time = " "
         }else{
            
             if(val > 60){
                 var totalmin = val % 60;
                 var totalhr = (val/60);
                 var strtotalhr = totalhr+"";
                 if(strtotalhr.includes(".")){
                    strtotalhr = strtotalhr.split(".")[0]
                 }
                 operational_time = strtotalhr +" hr "+totalmin+" min"
                 
             }else{
            	operational_time = val+" min"
             }
         }
         this.personList[id]["operationtime"] = operational_time;
        
      }
      if(property == "methoddegreasing"){
        if(Number(this.personList[id]['methoddegreasing']) > 4){
           this.error = true;
           this.errorMessage = "Method Of Degreasing should be in 1 to 4 "
            return false
        }
      }else{
        console.log("remove no match")  
      }

      //this.personList[id][property] = event.target.textContent;
      
      console.log(this.personList)
      
    }

    remove(id: any) {
      
      this.personList.splice(id, 1);
    }

    add() {
        
     
    }

    changeValue(id: number, property: string, event: any) {
        
        debugger
        this.personList[id][property] = "";
        
    }

    
    jobselect(jobid){
        this.jobId = jobid;
        this.httpClient.get("degreasing?jobId="+jobid).subscribe(res=>{
            let result= <any>res;
            
            console.log(result);
            this.personList = result;
            //you can do asomething, like
            
        });
    }

    getMinutes(time:string){
        debugger
        var res = time.split(":")
        var hr = res[0]
        var min = res[1];
        
        var startmin = (Number(hr) * 60)+parseInt(min)
        
        return startmin
        
    }
    getMinutesOld(time:string){
        debugger
        var res = time.split(":")
        var hr = res[0]
        if(time.includes("AM")){
            
            var min = res[1].replace("AM","")
            var startmin = (Number(hr) * 60)+parseInt(min)
            return startmin
    
        }else if(time.includes("PM")){
            var min = res[1].replace("PM","")
            var convertto24hrformat = parseInt(hr) + 12
            var endmin = (convertto24hrformat * 60)+parseInt(min)
            return endmin
        }
    }
    constructor(private httpClient:HttpClient,public datepipe: DatePipe) {
       
    }

    ngOnInit() {
        debugger
        this.httpClient.get("job").subscribe(res=>{
            let result= <any>res;
            this.jobList = result
            for(let j of this.jobList){
                this.TCNumberList.push(j.tcno)
                
                this.batchIdList.push(j.batchId)
            }
            console.log(result);
            
            //you can do asomething, like
            
        });

         //Get EMPList
         this.httpClient.get("/api/util/emp").subscribe(res=>{
         let result= <any>res;
        //here you received the response of your post
         this.EMPLIST = result
         console.log(result);
      })

      //Get EMPList
      this.httpClient.get("/api/util/degsupplier").subscribe(res=>{
        let result= <any>res;
        this.CONSUMABLE_SUPPLIER_DEG = result
       
     })

      //this.personList.push({id:-1, date:"",time:"",methoddegreasing:"",batchTemp:"",consumableSupplier:"",consumableBatchNo:"",consumableExpDate:"",stime:"",endtime:"",operationtime:"",operator:" "})
    }

    selectedOptionTC(){
        debugger
        for(let j of this.jobList){
            console.log(j.tcno);
            
            if(this.selected_tc_no == j.tcno){
                this.selected_client = j.clientName;
            }
        }
    }

    selectedOptionClient(){
        console.log(this.selected_client);
    }

    onOptionsSelected(event){
    
        console.log(event);
    }


    fetchData() {
       
        var selectedBatchJobId;
        for(let jobInfo of this.jobList){
            if(this.batchId == jobInfo.batchId){
                selectedBatchJobId = jobInfo.id;
                
                break;
            }
        }
        if(selectedBatchJobId){
            this.jobId = selectedBatchJobId;
            this.httpClient.get("degreasing?jobId="+selectedBatchJobId).subscribe(res=>{
            let result= <any>res;
            console.log(result);
            debugger
            this.personList = result;
            
            
            });
        }else{
            this.personList=[];
        }
        
    }
    Edit(value){
       
        this.SelectedRowId = value;
      
      }


      EditField(id: number,property: string){
        var propval = this.personList[id][property]
        if(id==0){
            this.personList.forEach(function (person) {
                person[property] = propval;
            }); 
        }
       
      }

    save(){
      
       if(this.jobId){
        var t = this.personList;
        //var payload = {"deagreasingList":this.personList}
         var payload=  {deagreasing: this.personList, jobId:this.jobId}
         this.httpClient.post("degreasing",payload).subscribe(res=>{
            this.sucess = true;
            this.sucessMessage = "Degreasing Saved Successfully";
            
         })
       }else{
        this.error = true;
        this.errorMessage = "Please select Batch Number"
       }
       
     
    }
    

    addNewRow(){
        if(this.jobId){
            let now =new Date();
            let latest_date =this.datepipe.transform(now, 'yyyy-MM-dd');
            this.personList.push({id:-1, date:latest_date,time:"",methoddegreasing:"",batchTemp:"",consumableSupplier:"",consumableBatchNo:"",consumableExpDate:"",stime:"",endtime:"",operationtime:"",operator:" "})
        }else{
            this.error = true;
        this.errorMessage = "Please select Batch Number"
        }
       
    }

    close(){
        this.error=false;
    }
    closeSuccess(){
        this.sucess=false;
    }
}
