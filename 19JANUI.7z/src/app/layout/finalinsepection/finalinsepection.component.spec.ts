import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinalinsepectionComponent } from './finalinsepection.component';

describe('FinalinsepectionComponent', () => {
  let component: FinalinsepectionComponent;
  let fixture: ComponentFixture<FinalinsepectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinalinsepectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinalinsepectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
