import { FinalinsepectionModule } from './finalinsepection.module';

describe('FinalinsepectionModule', () => {
  let finalinsepectionModule: FinalinsepectionModule;

  beforeEach(() => {
    finalinsepectionModule = new FinalinsepectionModule();
  });

  it('should create an instance', () => {
    expect(finalinsepectionModule).toBeTruthy();
  });
});
