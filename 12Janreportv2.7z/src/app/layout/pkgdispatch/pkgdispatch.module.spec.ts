import { PkgdispatchModule } from './pkgdispatch.module';

describe('PkgdispatchModule', () => {
  let pkgdispatchModule: PkgdispatchModule;

  beforeEach(() => {
    pkgdispatchModule = new PkgdispatchModule();
  });

  it('should create an instance', () => {
    expect(pkgdispatchModule).toBeTruthy();
  });
});
