import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CoatingComponent } from './coating.component';

const routes: Routes = [
    {
        path: '', component: CoatingComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CoatingRoutingModule {
}
