import { Component, OnInit } from '@angular/core';

import { routerTransition } from '../../router.animations';
import { HttpClient, HttpParams } from '@angular/common/http';
import * as $ from 'jquery';
// For autosuggest
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { DELEGATE_CTOR } from '@angular/core/src/reflection/reflection_capabilities';

@Component({
  selector: 'app-inspafterreparation',
  templateUrl: './inspafterreparation.component.html',
  styleUrls: ['./inspafterreparation.component.scss']
})
export class InspafterreparationComponent implements OnInit {
  inspectionList=[];
  // For autosuggest start
EMPLIST=[];
jobList=[];
public model: any;
jobId:String;
TCNumberList = []
clientNameList=[]

error:boolean;
errorMessage;
sucess:boolean;
sucessMessage;
// For autosuggest end
editField: string;



SelectedRowId: any = '';
ShowEditTable :boolean = false;
qualityInspector:string;
dateInspector:string;

batchId:string
batchIdList:any=[]
search = (text$: Observable<string>) =>
text$.pipe(
  debounceTime(200),
  distinctUntilChanged(),
  map(term => term.length < 1 ? []
    : this.EMPLIST.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
)




remove(id: any) {
  
  this.inspectionList.splice(id, 1);
}



changeValue(id: number, property: string, event: any) {
    
    this.inspectionList[id][property] = "";
    
}




getMinutes(time:string){
    debugger
    var res = time.split(":")
    var hr = res[0]
    var min = res[1];
    
    var startmin = (Number(hr) * 60)+parseInt(min)
    
    return startmin
    
}

constructor(private httpClient:HttpClient) {
   
}

ngOnInit() {

    this.httpClient.get("job").subscribe(res=>{
        let result= <any>res;
        this.jobList = result
        for(let j of this.jobList){
            this.batchIdList.push(j.batchId)
        }
        
    });

     //Get EMPList
     debugger
     this.httpClient.get("/api/util/emp").subscribe(res=>{
     let result= <any>res;
     this.EMPLIST = result
     
  })
}


fetchClientDetails(selectedJobId: any) {
    debugger
    this.jobId = selectedJobId;
    this.httpClient.get("inpsectionreparation?jobId="+selectedJobId).subscribe(res=>{
        let result= <any>res;

        this.inspectionList = result.inspectionAfterReparation;
        this.qualityInspector=result.qualityInpector;
        this.dateInspector=result.dateInspector;
    });
}
fetchData() {
       
    var selectedBatchJobId;
    for(let jobInfo of this.jobList){
        if(this.batchId == jobInfo.batchId){
            selectedBatchJobId = jobInfo.id;
            break;
        }
    }
    if(selectedBatchJobId){
        this.jobId =selectedBatchJobId
        this.httpClient.get("inpsectionreparation?jobId="+selectedBatchJobId).subscribe(res=>{
        let result= <any>res;
        console.log(result);
        
        this.inspectionList = result.inspectionAfterReparation;
        this.qualityInspector=result.qualityInpector;
        this.dateInspector=result.dateInspector;
        
        
        });
    }else{
        this.inspectionList = [];
        this.qualityInspector="";
        this.dateInspector="";
    }
    
}

searchBatch = (text$: Observable<string>) =>
text$.pipe(
debounceTime(200),
distinctUntilChanged(),
map(term => term.length < 1 ? []
: this.batchIdList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
)

Edit(value){
   
    this.SelectedRowId = value;
  
  }


  EditField(id: number,property: string){
    var propval = this.inspectionList[id][property]
    if(id==0){
        this.inspectionList.forEach(function (person) {
            person[property] = propval;
        }); 
    }
   
  }

save(){
  
   if(this.jobId){
    
     var payload=  {inspectionAfterReparation: this.inspectionList, jobId:this.jobId,qualityInpector:this.qualityInspector,dateInspector:this.dateInspector}
     this.httpClient.post("inpsectionreparation",payload).subscribe(res=>{
        this.sucess = true;
        this.sucessMessage = "Inspection Adfter Reparation Saved Successfully";
        
     })
   }else{
    this.error = true;
    this.errorMessage = "Please select Batch Number"
   }
   
 
}

addNewRow(){
  this.inspectionList.push({id:-1, partIdentification:"",pcs:"",thickness_min:"",thickness_max:"",thickness_average:"",visualcontrol:"",curingtest:"",note:""})
}

close(){
    this.error=false;
}
closeSuccess(){
    this.sucess=false;
}

}
