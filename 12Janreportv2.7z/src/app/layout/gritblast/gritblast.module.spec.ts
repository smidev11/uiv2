import { GritblastModule } from './gritblast.module';

describe('GritblastModule', () => {
  let gritblastModule: GritblastModule;

  beforeEach(() => {
    gritblastModule = new GritblastModule();
  });

  it('should create an instance', () => {
    expect(gritblastModule).toBeTruthy();
  });
});
