import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GritblastComponent } from './gritblast.component';

const routes: Routes = [
    {
        path: '', component: GritblastComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class GritblastRoutingModule {
}
