import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GritblastComponent } from './gritblast.component';

describe('GritblastComponent', () => {
  let component: GritblastComponent;
  let fixture: ComponentFixture<GritblastComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GritblastComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GritblastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
