import { Component, OnInit } from '@angular/core';

import { routerTransition } from '../../router.animations';
import { HttpClient, HttpParams } from '@angular/common/http';
import * as $ from 'jquery';
// For autosuggest
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { DELEGATE_CTOR } from '@angular/core/src/reflection/reflection_capabilities';
import { DatePipe } from '@angular/common'

@Component({
  selector: 'app-gritblast',
  templateUrl: './gritblast.component.html',
  styleUrls: ['./gritblast.component.scss']
})
export class GritblastComponent implements OnInit {

 // For autosuggest start
 EMPLIST=[];
 jobList=[];
 public model: any;
 jobId:String;
 //TCNumberList = []
 clientNameList=[]
 selected_tc_no;
 selected_client;
 error:boolean;
 errorMessage;
 sucess:boolean;
 sucessMessage;
 // For autosuggest end
 editField: string;
 gritBlastList: Array<any> = [ ];

 TableData: any = [];
 SelectedRowId: any = '';
 ShowEditTable :boolean = false;
 batchId:string
 batchIdList:any=[]
 
 GRIT_BLAST_METHOD_LIST = []
 //searchTC = (text$: Observable<string>) =>
 //text$.pipe(
  // debounceTime(200),
  // distinctUntilChanged(),
  // map(term => term.length < 1 ? []
    // : this.TCNumberList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
 //)

 search = (text$: Observable<string>) =>
 text$.pipe(
   debounceTime(200),
   distinctUntilChanged(),
   map(term => term.length < 1 ? []
     : this.EMPLIST.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
 )


 

  updateList(id: number,property: string,event: any) {
   
   if(property == "endtime"){
      debugger
      var tempstarttime = this.gritBlastList[id]['stime']
      var tempendtime = this.gritBlastList[id]['endtime']

      var stime = this.getMinutes(tempstarttime);
      var etime = this.getMinutes(tempendtime)
      var val = (Number(etime) - Number(stime))
      var operational_time = " ";
      
      if(val < 0){
         operational_time = " "
      }else{
         
          if(val > 60){
              var totalmin = val % 60;
              var totalhr = (val/60);
              var strtotalhr = totalhr+"";
              if(strtotalhr.includes(".")){
                 strtotalhr = strtotalhr.split(".")[0]
              }
              operational_time = strtotalhr +" hr "+totalmin+" min"
              
          }else{
            operational_time = val+" min"
          }
      }
      this.gritBlastList[id]["operationtime"] = operational_time;
     
   }
   
 }

 remove(id: any) {
   
   this.gritBlastList.splice(id, 1);
 }

 

 changeValue(id: number, property: string, event: any) {
     
     this.gritBlastList[id][property] = "";
     
 }

 
 jobselect(jobid){
     this.jobId = jobid;
     this.httpClient.get("gritblast?jobId="+jobid).subscribe(res=>{
         let result= <any>res;
         
         console.log(result);
         this.gritBlastList = result;
         //you can do asomething, like
         
     });
 }

 getMinutes(time:string){
     debugger
     var res = time.split(":")
     var hr = res[0]
     var min = res[1];
     
     var startmin = (Number(hr) * 60)+parseInt(min)
     
     return startmin
     
 }

 constructor(private httpClient:HttpClient,public datepipe: DatePipe) {
    
 }

 searchSupplier = (text$: Observable<string>) =>
 text$.pipe(
 debounceTime(200),
 distinctUntilChanged(),
 map(term => term.length < 1 ? []
 : this.CONSUMABLE_SUPPLIER_DEG.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
 )

 searchGritBlastMethod = (text$: Observable<string>) =>
 text$.pipe(
 debounceTime(200),
 distinctUntilChanged(),
 map(term => term.length < 1 ? []
 : this.GRIT_BLAST_METHOD_LIST.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
 )

 CONSUMABLE_SUPPLIER_DEG:any=[]
 ngOnInit() {

     this.httpClient.get("job").subscribe(res=>{
         let result= <any>res;
         this.jobList = result
         for(let j of this.jobList){
            // this.TCNumberList.push(j.tcno)
             this.batchIdList.push(j.batchId)
         }
         
     });

     this.httpClient.get("/api/util/bastingsupplier").subscribe(res=>{
        let result= <any>res;
        this.CONSUMABLE_SUPPLIER_DEG = result
       
        
    });

    //Get EMPList
    this.httpClient.get("/api/util/gritblastmethods").subscribe(res=>{
        let result= <any>res;
        this.GRIT_BLAST_METHOD_LIST = result
       
     })

      this.httpClient.get("/api/util/emp").subscribe(res=>{
      let result= <any>res;
      this.EMPLIST = result
      
   })

   this.gritBlastList.push({id:-1, date:"",time:"",blastingMethod:"",ambientTemp:"",dewTemp:"",avgPartTemp:"",humidity:"",consumableSupplier:"",stime:"",endtime:"",operationtime:"",surfaceProfile:" "})
 }

 /** 
 selectedOptionTC(){
     debugger
     for(let j of this.jobList){
         console.log(j.tcno);
         
         if(this.selected_tc_no == j.tcno){
             this.selected_client = j.clientName;
         }
     }
 }
 selectedOptionClient(){
     console.log(this.selected_client);
 }

 onOptionsSelected(event){
 
     console.log(event);
 }
 */

 //fetchClientDetails(selectedJobId: any) {
     
   //  this.jobId = selectedJobId;
 //    this.httpClient.get("gritblast?jobId="+selectedJobId).subscribe(res=>{
  //       let result= <any>res;
   //      this.gritBlastList = result;
  //   });
 //}
 Edit(value){
    
     this.SelectedRowId = value;
   
   }


   //EditField(id: number,property: string){
   //  var propval = this.gritBlastList[id][property]
   //  if(id==0){
   //      this.gritBlastList.forEach(function (person) {
    //         person[property] = propval;
    //     }); 
    // }
    
 //  }

 save(){
   
    if(this.jobId){
     var t = this.gritBlastList;
      var payload=  {gritblast: this.gritBlastList, jobId:this.jobId}
      this.httpClient.post("gritblast",payload).subscribe(res=>{
         this.sucess = true;
         this.sucessMessage = "GritBlast Saved Successfully";
         
      })
    }else{
     this.error = true;
     this.errorMessage = "Please select Batch Number"
    }
    
  
 }

 addNewRow(){
    if(this.jobId){
        let now =new Date();
        let latest_date =this.datepipe.transform(now, 'yyyy-MM-dd');
        
         this.gritBlastList.push({id:-1, date:latest_date,time:"",blastingMethod:"",ambientTemp:"",dewTemp:"",avgPartTemp:"",humidity:"",consumableSupplier:"",stime:"",endtime:"",operationtime:"",surfaceProfile:" "})
    }else{
        this.error = true;
        this.errorMessage = "Please select Batch Number"
    }
   
 }

 close(){
     this.error=false;
 }
 closeSuccess(){
     this.sucess=false;
 }

 fetchData() {
       
    var selectedBatchJobId;
    for(let jobInfo of this.jobList){
        if(this.batchId == jobInfo.batchId){
            selectedBatchJobId = jobInfo.id;
            break;
        }
    }
    if(selectedBatchJobId){
        this.jobId =selectedBatchJobId
        this.httpClient.get("gritblast?jobId="+selectedBatchJobId).subscribe(res=>{
        let result= <any>res;
        console.log(result);
        
        this.gritBlastList = result;
        
        
        });
    }else{
        this.gritBlastList=[];
    }
    
}


searchBatch = (text$: Observable<string>) =>
text$.pipe(
debounceTime(200),
distinctUntilChanged(),
map(term => term.length < 1 ? []
: this.batchIdList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
)
}
