import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { HttpClient, HttpParams } from '@angular/common/http';
import * as $ from 'jquery';
// For autosuggest
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { DELEGATE_CTOR } from '@angular/core/src/reflection/reflection_capabilities';
import { DatePipe } from '@angular/common'
import { debug } from 'util';

@Component({
  selector: 'app-phosphating',
  templateUrl: './phosphating.component.html',
  styleUrls: ['./phosphating.component.scss']
})


export class PhosphatingComponent implements OnInit {// For autosuggest start
    EMPLIST = [];
    jobList = [];
    public model: any;
    jobId: String;
    TCNumberList = []
    clientNameList = []
    selected_tc_no;
    selected_client;
    error: boolean;
    errorMessage;
    sucess: boolean;
    sucessMessage;
    // For autosuggest end
    editField: string;
    activationLink: Array<any> = [];
  
    TableData: any = [];
    SelectedRowId: any = '';
    ShowEditTable: boolean = false;
    
    PH_TYPE_LIST:any=["Zinc","Manganese","Other"]
  
  
    //////
    commonList:any=[]
    activationList:any=[]
    phList:any=[]
    psList:any=[];
    batchId:string
    batchIdList:any=[];
  
  
    sucessCommon:boolean;
    sucessMessageCommon;
    errorCommon :boolean;
    errorMessageCommon;
  
  
    sucessActivation:boolean;
    sucessMessageActivation;
    errorActivation :boolean;
    errorMessageActivation;
  
  
    errorPH:boolean;
    errorMessagePH;
    sucessPH:boolean;
    sucessMessagePH;
  
    errorPS:boolean;
    errorMessagePS;
    sucessPS:boolean;
    sucessMessagePS;

    masterData;
  
    searchTC = (text$: Observable<string>) =>
      text$.pipe(
        debounceTime(200),
        distinctUntilChanged(),
        map(term => term.length < 1 ? []
          : this.TCNumberList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
      )
  
    search = (text$: Observable<string>) =>
      text$.pipe(
        debounceTime(200),
        distinctUntilChanged(),
        map(term => term.length < 1 ? []
          : this.EMPLIST.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
      )
  
      searchPhType = (text$: Observable<string>) =>
      text$.pipe(
        debounceTime(200),
        distinctUntilChanged(),
        map(term => term.length < 1 ? []
          : this.PH_TYPE_LIST.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
      )
  
    updateList(id: number, tblDate:any,property: string, type:string,event: any) {
      debugger
     
      if (property == "endtime") {
        
        var tempstarttime = tblDate[id]['stime']
        var tempendtime = tblDate[id]['endtime']
  
        var stime = this.getMinutes(tempstarttime);
        var etime = this.getMinutes(tempendtime)

        
        var val = (Number(etime) - Number(stime))
        var operational_time = " ";
  
        if (val < 0) {
          operational_time = " "
        } else {
  
          if (val > 60) {
            var totalmin = val % 60;
            var totalhr = (val / 60);
            var strtotalhr = totalhr + "";
            if (strtotalhr.includes(".")) {
              strtotalhr = strtotalhr.split(".")[0]
            }
            operational_time = strtotalhr + " hr " + totalmin + " min"
  
          }else{
            	operational_time = val+" min"
          }
        }
        var isError:boolean = false;
        var eMessage;
        if(etime < stime){
          isError = true;
          eMessage = "Start time should be less than end time"
          return
        }
        
        if(type == "activation"){
          var masterDataValOpTime = this.masterData.phactivationOPTime;
          if(masterDataValOpTime != null){
            var valArr = masterDataValOpTime.split(" ");
            var rangeStart = valArr[0].trim();
            var rangeEnd =   valArr[2].trim();
            var unit =  valArr[3].trim();
    
            if(val < Number(rangeStart) || val > Number(rangeEnd) ){
              this.errorActivation = true;
              
              this.errorMessageActivation = "Activation bath operational time should be between "+rangeStart + " and "+rangeEnd +" Minutes";
            }
          }
        }

        if(type == "phosphate"){
          var masterDataPHOpTime = this.masterData.phphoptime;
          if(masterDataPHOpTime != null){
            var valArr = masterDataPHOpTime.split(" ");
            var rangeStart = valArr[0].trim();
            var rangeEnd =   valArr[2].trim();
            var unit =  valArr[3].trim();
    
            if(val < Number(rangeStart) || val > Number(rangeEnd) ){
              this.errorPH = true;
              this.errorMessagePH = "Phosphate operational time should be between "+rangeStart + " and "+rangeEnd +" Minutes";
            }
          }
        }

        if(type == "passivation"){
          var masterDataPSOpTime = this.masterData.phpassivationOPTime;
          if(masterDataPSOpTime != null){
            var valArr = masterDataPSOpTime.split(" ");
            var rangeStart = valArr[0].trim();
            var rangeEnd =   valArr[2].trim();
            var unit =  valArr[3].trim();
    
            if(val < Number(rangeStart) || val > Number(rangeEnd) ){
              this.errorPS = true;
              this.errorMessagePS = "Passivation operational time should be between "+rangeStart + " and "+rangeEnd +" Minutes";
            }
          }
        }
        
        
        
       
        tblDate[id]["operationtime"] = operational_time;
  
      }
  
     
  
    }
  
    remove(id: any) {
  
      this.activationLink.splice(id, 1);
    }
  
  
  
    changeValue(id: number, property: string, event: any) {
  
      this.activationLink[id][property] = "";
  
    }
  
  
    jobselect(jobid) {
      this.jobId = jobid;
      this.httpClient.get("gritblast?jobId=" + jobid).subscribe(res => {
        let result = <any>res;
  
        console.log(result);
        this.activationLink = result;
        //you can do asomething, like
  
      });
    }
  
    getMinutes(time: string) {
      
      var res = time.split(":")
      var hr = res[0]
      var min = res[1];
  
      var startmin = (Number(hr) * 60) + parseInt(min)
  
      return startmin
  
    }
  
    constructor(private httpClient: HttpClient,public datepipe: DatePipe) {
  
    }
    CONSUMABLE_SUPPLIER_PH:any=[]
    ngOnInit() {
  
      this.httpClient.get("job").subscribe(res => {
        let result = <any>res;
        this.jobList = result
        for (let j of this.jobList) {
          this.batchIdList.push(j.batchId)
        }
  
      });
  
    
      this.httpClient.get("/api/util/emp").subscribe(res => {
        let result = <any>res;
        this.EMPLIST = result
  
      })

      this.httpClient.get("/api/util/phsupplier").subscribe(res=>{
        let result= <any>res;
        this.CONSUMABLE_SUPPLIER_PH = result
      });

     

    }
  
    searchSupplier = (text$: Observable<string>) =>
    text$.pipe(
    debounceTime(200),
    distinctUntilChanged(),
    map(term => term.length < 1 ? []
    : this.CONSUMABLE_SUPPLIER_PH.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )

    selectedOptionTC() {
      
      for (let j of this.jobList) {
        console.log(j.tcno);
  
        if (this.selected_tc_no == j.tcno) {
          this.selected_client = j.clientName;
        }
      }
    }
  
    selectedOptionClient() {
      console.log(this.selected_client);
    }
  
    onOptionsSelected(event) {
  
      console.log(event);
    }
  
    fetchClientDetails(selectedJobId: any) {
  
      this.jobId = selectedJobId;
      this.httpClient.get("activation?jobId=" + selectedJobId).subscribe(res => {
        let result = <any>res;
        this.activationLink = result;
      });
    }
    Edit(value) {
  
      this.SelectedRowId = value;
  
    }
  
  
    EditField(id: number, property: string) {
      var propval = this.activationLink[id][property]
      if (id == 0) {
        this.activationLink.forEach(function (person) {
          person[property] = propval;
        });
      }
  
    }
  
    saveCommon() {
  
      if (this.jobId) {
        
        var payload = { phCommon: this.commonList, jobId: this.jobId }
        this.httpClient.post("phcommon", payload).subscribe(res => {
          this.sucessCommon = true;
          this.sucessMessageCommon = "Common Details Saved Successfully";
  
        })
      } else {
        this.errorCommon = true;
        this.errorMessageCommon = "Please select Batch Number"
      }
    }
  
    validateActivationBathOverallPointingVal() {
      var val = this.masterData.phactivationBathOverallPointingVal;
      if(val != null){
        var valArr = val.split("to");
        var rangeStart = valArr[0].trim();
        var rangeEnd = valArr[1].trim();
      
        for (let tempActivation of this.activationList) {
          if(tempActivation['bathValue'] < Number(rangeStart) || tempActivation['bathValue'] > Number(rangeEnd) ){
            this.errorActivation = true;
            this.errorMessageActivation = "Activation Bath Overall Pointing Value should be between "+rangeStart + " and "+rangeEnd;
            return false;
          }
        }
    
      } 
      return true;
    }
    
    validateActivationBathTempVal() {
      var val = this.masterData.phactivationBathTemp;
      if(val != null){
        var valArr = val.split("to");
        var rangeStart = valArr[0].trim();
        var rangeEnd = valArr[1].trim();
      
        for (let tempActivation of this.activationList) {
          if(tempActivation['bathTemp'] < Number(rangeStart) || tempActivation['bathTemp'] > Number(rangeEnd) ){
            this.errorActivation = true;
            this.errorMessageActivation = "Activation Bath Temp should be between "+rangeStart + " and "+rangeEnd;
            return false;
          }
        }
    
      } 
      return true;
    }

    /*
    validateActivationOPTime() {
     
      var val = this.masterData.phactivationOPTime;
      if(val != null){
        var valArr = val.split(" ");
        var rangeStart = valArr[0].trim();
        var rangeEnd =   valArr[2].trim();
        var unit =  valArr[3].trim();

        for (let tempActivation of this.activationList) {
          var opinputTime  =  tempActivation['operationtime'];
         
          var optimeInMinutes = opinputTime.split(" ")[3];
          if(optimeInMinutes == "min"){
            if(optimeInMinutes < Number(rangeStart) || optimeInMinutes > Number(rangeEnd) ){
              this.errorActivation = true;
              this.errorMessageActivation = "Activation Bath Operational Time should be between "+rangeStart + " and "+rangeEnd;
              return false;
            }
          }
          
        }
      
        
    
      } 
      return true;
    }
    */



    saveActivation() {
      
      if(this.masterData.applycheck == "Y"){
        if(! this.validateActivationBathOverallPointingVal()){
          return
        }

        if(! this.validateActivationBathTempVal()){
          return
        }
      }

      

      if (this.jobId) {
       
        var payload = { activation: this.activationList, jobId: this.jobId }
        this.httpClient.post("activation", payload).subscribe(res => {
          this.sucessActivation = true;
          this.sucessMessageActivation = "Activatoin Saved Successfully";
  
        })
      } else {
        this.errorActivation = true;
        this.errorMessageActivation = "Please Select Batch Number"
      }
    }
  
   
    validateWt() {
        var phwt = this.masterData.phosphatWeight;
        if(phwt != null){
          var phwtVal = phwt.split(" ");
          if(phwtVal[1] == "minimum"){
            var wtNumber = Number(phwtVal[0]);
            for (let tempPh of this.phList) {
              if(tempPh['phweight'] <  wtNumber){
                this.errorPH = true;
                this.errorMessagePH = "Save Failed. Phosphate Weight should be minimum 15 gm/m²"
                return false;
              }
            }
          }
      
        } 
        return true;
    }

    
    validatePHOverallPointingVal() {
      var val = this.masterData.phphoverallPointingVal;
      if(val != null){
        var valArr = val.split("to");
        var rangeStart = valArr[0].trim();
        var rangeEnd = valArr[1].trim();
      
        for (let tempPhList of this.phList) {
          if(tempPhList['phBathVal'] < Number(rangeStart) || tempPhList['phBathVal'] > Number(rangeEnd) ){
            this.errorPH = true;
            this.errorMessagePH = "Phosphate Overall Pointing Value should be between "+rangeStart + " and "+rangeEnd;
            return false;
          }
        }
    
      } 
      return true;
    }

    validatePHBathTemp(){
      var val = this.masterData.phphbathTemp;
      if(val != null){
        var valArr = val.split("to");
        var rangeStart = valArr[0].trim();
        var rangeEnd = valArr[1].trim();
      
        for (let tempPhList of this.phList) {
          if(tempPhList['bathTemp'] < Number(rangeStart) || tempPhList['bathTemp'] > Number(rangeEnd) ){
            this.errorPH = true;
            this.errorMessagePH = "Phosphating Bath Temperature Value should be between "+rangeStart + " and "+rangeEnd;
            return false;
          }
        }
    
      } 
      return true;
    }
    validatePHBathFreeAcidPOVal() {
      var val = this.masterData.phphbathFreeAcidPointingVals;
      if(val != null){
        var valArr = val.split("to");
        var rangeStart = valArr[0].trim();
        var rangeEnd = valArr[1].trim();
      
        for (let tempPhList of this.phList) {
          if(tempPhList['phAcidVal'] < Number(rangeStart) || tempPhList['phAcidVal'] > Number(rangeEnd) ){
            this.errorPH = true;
            this.errorMessagePH = "Phosphating Bath Free Acids Pointing Valueshould be between "+rangeStart + " and "+rangeEnd;
            return false;
          }
        }
    
      } 
      return true;
    }
    savePH() {
      
      if(this.masterData.applycheck == "Y"){
        if(! this.validateWt()){
          return
        }

        if(! this.validatePHOverallPointingVal()){
          return
        }

        if(! this.validatePHBathFreeAcidPOVal()){
          return
        }

        if(! this.validatePHBathTemp()){
          return
        }
      }
     
      if (this.jobId) {
        var payload = { phosphating: this.phList, jobId: this.jobId }
        this.httpClient.post("phosphating", payload).subscribe(res => {
          this.sucessPH = true;
          this.sucessMessagePH = "Phosphating Saved Successfully";
  
        })
      } else {
        this.errorPH = true;
        this.errorMessagePH = "Please select Batch Number"
      }
    }
  

    validatePSOverallPOVal(){
      var val = this.masterData.phpassivationBathTemp;
      if(val != null){
        var valArr = val.split("to");
        var rangeStart = valArr[0].trim();
        var rangeEnd = valArr[1].trim();
      
        for (let tempPSList of this.psList) {
          if(tempPSList['psBathVal'] < Number(rangeStart) || tempPSList['psBathVal'] > Number(rangeEnd) ){
            this.errorPS = true;
            this.errorMessagePS = "Passivation Bath Overall Pointing Value should be between "+rangeStart + " and "+rangeEnd;
            return false;
          }
        }
    
      } 
      return true;
    }

    validatePSBathTemp(){
      var val = this.masterData.phpassivationBathTemp;
      if(val != null){
        var valArr = val.split("to");
        var rangeStart = valArr[0].trim();
        var rangeEnd = valArr[1].trim();
      
        for (let tempPSList of this.psList) {
          if(tempPSList['psBathTemp'] < Number(rangeStart) || tempPSList['psBathTemp'] > Number(rangeEnd) ){
            this.errorPS = true;
            this.errorMessagePS = "Passivation Bath Temperature Value should be between "+rangeStart + " and "+rangeEnd;
            return false;
          }
        }
    
      } 
      return true;
    }

    savePS() {
      if(this.masterData.applycheck == "Y"){
        if(! this.validatePSOverallPOVal()){
          return
        }

        if(! this.validatePSBathTemp()){
          return
        }
      }

      if (this.jobId) {
        
        var payload = { passivation: this.psList, jobId: this.jobId }
        this.httpClient.post("passivation", payload).subscribe(res => {
          this.sucessPS= true;
          this.sucessMessagePS = "Passivation Saved Successfully";
  
        })
      } else {
        this.errorPS = true;
        this.errorMessagePS = "Please select Batch Number"
      }
    }
    addNewRowCommon() {
      if(this.jobId){
        let now =new Date();
        let latest_date =this.datepipe.transform(now, 'yyyy-MM-dd');
        this.commonList.push({ id: -1, date:latest_date ,time: "",coatingSystem: "",ambientTemp: "",dewTemp: "",partTemp: "",humidity: "",phosphatingChemSupplier: "",operatorstime: "" })
      }else{
        this.errorCommon = true;
        this.errorMessageCommon = "Please select Batch Number"
      }
     
    }
  
    addNewRowActivation() {
      if(this.jobId){
        this.activationList.push({ id: -1, consumableCode:"",consumable:"",bathValue:"",bathTemp:"",stime:"",endtime:"",operationtime:""})
      }else{
        this.errorActivation = true;
        this.errorMessageActivation = "Please Select Batch Number"
      }
     
    }
    addNewRowPH(){
      if(this.jobId){
        this.phList.push({ id: -1, phConsumableCode:"",phConsumbaleExp:"",phBathVal:"",phAcidVal:"",bathTemp:"",stime:"",endtime:"",operationtime:""})
      }else{
        this.errorPH = true;
        this.errorMessagePH = "Please select Batch Number"
      }
      
    }
  
    addNewRowPS(){
      
      if(this.jobId){
        this.psList.push({id:-1,psSupplier:"",psConsumableCode:"",psConsumbaleExp:"",psBathVal:"",psBath:"",psBathTemp:"",stime:"",endtime:"",operationtime:""})
      }else{
        this.errorPS = true;
        this.errorMessagePS = "Please select Batch Number"
      }
      
    }
  
  
    fetchData() {
         
          var selectedBatchJobId;
          for(let jobInfo of this.jobList){
              if(this.batchId == jobInfo.batchId){
                  selectedBatchJobId = jobInfo.id;
                  break;
              }
          }
          if(selectedBatchJobId){
              this.jobId = selectedBatchJobId;

              //Get the validation data from master list
              debugger
              this.httpClient.get("/api/util/jobMasterList?jobId="+selectedBatchJobId).subscribe(res=>{
                let result= <any>res;
                this.masterData = result;
              });
              
              this.httpClient.get("phcommon?jobId="+selectedBatchJobId).subscribe(res=>{
                let result= <any>res;
                this.commonList = result;
              });
  
              this.httpClient.get("activation?jobId="+selectedBatchJobId).subscribe(res=>{
                let result= <any>res;
                this.activationList = result;
              });
  
  
              this.httpClient.get("phosphating?jobId="+selectedBatchJobId).subscribe(res=>{
                let result= <any>res;
                this.phList = result;
              });
  
              this.httpClient.get("passivation?jobId="+selectedBatchJobId).subscribe(res=>{
                let result= <any>res;
                this.psList = result;
              });
          }else{
              this.commonList=[];
              this.activationList = [];
              this.phList = [];
              this.psList = [];
          }
          
      }
  
      searchBatch = (text$: Observable<string>) =>
      text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term => term.length < 1 ? []
      : this.batchIdList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
      )
    
    
    closeErrorCommon() {
      this.errorCommon = false;
    }
    closeSuccessCommon() {
      this.sucessCommon = false;
    }
  
    closeErrorActivation() {
      this.errorActivation=false;
    }
    closeSuccessActivation() {
      this.sucessActivation = false;
    }
  
    closeErrorPH(){
      this.errorPH=false;
    }
    
    closeSuccessPH(){
      this.sucessPH=false;
    }
  
    closeErrorPS(){
      this.errorPS=false;
    }
    
    closeSuccessPS(){
      this.sucessPS=false;
    }
  }