import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PkgdispatchComponent } from './pkgdispatch.component';

describe('PkgdispatchComponent', () => {
  let component: PkgdispatchComponent;
  let fixture: ComponentFixture<PkgdispatchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PkgdispatchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PkgdispatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
