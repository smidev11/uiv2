import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NonconformityComponent } from './nonconformity.component';

const routes: Routes = [
    {
        path: '', component: NonconformityComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class NonconformityRoutingModule {
}
