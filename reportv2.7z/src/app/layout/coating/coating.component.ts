import { Component, OnInit } from '@angular/core';


import { routerTransition } from '../../router.animations';
import { HttpClient, HttpParams } from '@angular/common/http';
import * as $ from 'jquery';
// For autosuggest
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { DELEGATE_CTOR } from '@angular/core/src/reflection/reflection_capabilities';
import {NgbDateStruct, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common'
@Component({
  selector: 'app-coating',
  templateUrl: './coating.component.html',
  styleUrls: ['./coating.component.scss']
})
export class CoatingComponent implements OnInit {
 EMPLIST=[];
 jobList=[];
 jobId:String;

 error1201:boolean;
 errorMessage1201;
 sucess1201:boolean;
 sucessMessage1201;
 everslik1201List: Array<any> = [ ];
 SelectedRowId: any = '';
 //model: NgbDateStruct
 
 batchId:string
 batchIdList:any=[];
 errorCuring1201:boolean;
 errorMessageCuring1201;
 sucessCuring1201:boolean;
 sucessMessageCuring1201;
 everslikCuringList: Array<any> = [ ];

 masterData;
 //errorCuring1301:boolean;
 //errorMessageCoating2;
 //sucessCuring1301:boolean;
 //sucessMessageCuring1301;
 //sucessMessageCoating2: Array<any> = [ ];



 errorCoating2:boolean;
 errorMessageCoating2;
 sucessCoating2:boolean;
 sucessMessageCoating2;
 coating2List: Array<any> = [ ];

 errorCuring2:boolean;
 errorMessageCuring2;
 sucessCuring2:boolean;
 sucessMessageCuring2;
 curing2List: Array<any> = [ ];

 COATING_SUPPLIER:Array<any> = [];


OVEN_NO_LIST:Array<any>=[];

 search = (text$: Observable<string>) =>
 text$.pipe(
   debounceTime(200),
   distinctUntilChanged(),
   map(term => term.length < 1 ? []
     : this.EMPLIST.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
 )



 getFlashDuration(id: number,tblData,property: string,event: any) {
   
    if(property == "flashEnd"){
       
       var tempstarttime = tblData[id]['flashtStart']
       var tempendtime = tblData[id]['flashEnd']
 
       var stime = this.getMinutes(tempstarttime);
       var etime = this.getMinutes(tempendtime)
       var val = (Number(etime) - Number(stime))
       var operational_time = " ";
       
       if(val < 0){
          operational_time = " "
       }else{
          
           if(val > 60){
               var totalmin = val % 60;
               var totalhr = (val/60);
               var strtotalhr = totalhr+"";
               if(strtotalhr.includes(".")){
                  strtotalhr = strtotalhr.split(".")[0]
               }
               operational_time = strtotalhr +" hr "+totalmin+" min"
               
           }else{
            operational_time = val+" min"
          }
       }
       tblData[id]["flashDuration"] = operational_time;
      
    }
    
  }

  getFinalDuration(id: number,tblData,property: string,event: any) {
   
    if(property == "finalEnd"){
       
       var tempstarttime = tblData[id]['finalStart']
       var tempendtime = tblData[id]['finalEnd']
 
       var stime = this.getMinutes(tempstarttime);
       var etime = this.getMinutes(tempendtime)
       var val = (Number(etime) - Number(stime))
       var operational_time = " ";
       
       if(val < 0){
          operational_time = " "
       }else{
          
           if(val > 60){
               var totalmin = val % 60;
               var totalhr = (val/60);
               var strtotalhr = totalhr+"";
               if(strtotalhr.includes(".")){
                  strtotalhr = strtotalhr.split(".")[0]
               }
               operational_time = strtotalhr +" hr "+totalmin+" min"
               
           }else{
            operational_time = val+" min"
          }
       }
       tblData[id]["finalDuration"] = operational_time;
      
    }
    
  }

  updateList(id: number,tblData,property: string,event: any) {
   
   if(property == "endtime"){
      
      var tempstarttime = tblData[id]['stime']
      var tempendtime = tblData[id]['endtime']

      var stime = this.getMinutes(tempstarttime);
      var etime = this.getMinutes(tempendtime)
      var val = (Number(etime) - Number(stime))
      var operational_time = " ";
      
      if(val < 0){
         operational_time = " "
      }else{
         
          if(val > 60){
              var totalmin = val % 60;
              var totalhr = (val/60);
              var strtotalhr = totalhr+"";
              if(strtotalhr.includes(".")){
                 strtotalhr = strtotalhr.split(".")[0]
              }
              operational_time = strtotalhr +" hr "+totalmin+" min"
              
          }else{
            operational_time = val+" min"
          }
      }
      tblData[id]["operationtime"] = operational_time;
     
   }
   
 }

 remove1201(id: any) {
   this.everslik1201List.splice(id, 1);
 }

 removecuring1201(id: any){
    this.everslikCuringList.slice(id,1);
}

 removeCoating2(id: any) {
    this.coating2List.splice(id, 1);
}
  
removecuring2(id: any){
    this.curing2List.slice(id,1);
}
 
 getMinutes(time:string){
     debugger
     var res = time.split(":")
     var hr = res[0]
     var min = res[1];
     var startmin = (Number(hr) * 60)+parseInt(min)
     return startmin
     
 }

 constructor(private httpClient:HttpClient,public datepipe: DatePipe) {
    
 }

 ngOnInit() {

     this.httpClient.get("job").subscribe(res=>{
         let result= <any>res;
         
         this.jobList = result
         for (let j of this.jobList) {
            this.batchIdList.push(j.batchId)
          }
     });


     this.httpClient.get("api/util/coatsupplier").subscribe(res=>{
        let result= <any>res;
        this.COATING_SUPPLIER = result;
        
    });

    this.httpClient.get("api/util/ovennumber").subscribe(res=>{
        let result= <any>res;
        this.OVEN_NO_LIST= result;
    });



      this.httpClient.get("/api/util/emp").subscribe(res=>{
      let result= <any>res;
      this.EMPLIST = result
      
      
   })

   //this.everslik1201List.push({id:-1,date:"",time:"",ambiantTemp:"",dewTemp:"",partTemp:"",humidity:"",coatingsys:"",coatingbatch:"",mgfDate:"",expDate:"",stime:"",endtime:"",operationtime:"",dryFlimTickness:"",operator:""})
 }

 searchCoatSupplier = (text$: Observable<string>) =>
 text$.pipe(
 debounceTime(200),
 distinctUntilChanged(),
 map(term => term.length < 1 ? []
 : this.COATING_SUPPLIER.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
 )

 searchOvenNo = (text$: Observable<string>) =>
 text$.pipe(
 debounceTime(200),
 distinctUntilChanged(),
 map(term => term.length < 1 ? []
 : this.OVEN_NO_LIST.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
 )

 searchBatch = (text$: Observable<string>) =>
      text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term => term.length < 1 ? []
      : this.batchIdList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
      )
 coatingSysString :string;
 fetchData() {
     
    var selectedBatchJobId;
    for(let jobInfo of this.jobList){
        if(this.batchId == jobInfo.batchId){
           
            this.coatingSysString = jobInfo.genref.coatingsys
            selectedBatchJobId = jobInfo.id;
            break;
        }
    }
    if(selectedBatchJobId){
        this.httpClient.get("/api/util/jobMasterList?jobId="+selectedBatchJobId).subscribe(res=>{
            let result= <any>res;
            this.masterData = result;
          });


        this.jobId = selectedBatchJobId;
        this.httpClient.get("everslik1201?jobId="+selectedBatchJobId).subscribe(res=>{
            let result= <any>res;
            this.everslik1201List = result;
        });
   
        this.httpClient.get("flashcuring1201?jobId="+selectedBatchJobId).subscribe(res=>{
           let result= <any>res;
           this.everslikCuringList = result;
       });
   
       this.httpClient.get("everslik1301?jobId="+selectedBatchJobId).subscribe(res=>{
       
            let result= <any>res;
           this.coating2List = result;
       });
   
       this.httpClient.get("flashcuring1301?jobId="+selectedBatchJobId).subscribe(res=>{
           let result= <any>res;
           this.curing2List = result;
       });
    }else{
        this.everslik1201List=[];
        this.everslikCuringList = [];
        this.coating2List = [];
        this.curing2List = [];
    }
    
     
 }

 Edit(value){
    
    this.SelectedRowId = value;
  
  }


 validateCoat1DryFilm(){
    var val = this.masterData.baseCoatThicknessRequired;
    if(val != null){
      var valArr = val.split("to");
      var rangeStart = valArr[0].trim();
      var rangeEnd = valArr[1].trim();
    
      for (let tempList of this.everslik1201List) {
        if(tempList['dryFlimTickness'] < Number(rangeStart) || tempList['dryFlimTickness'] > Number(rangeEnd) ){
          this.errorCoating2 = true;
          this.errorMessageCoating2 = "Dry Flim Thinckness Value should be between "+rangeStart + " and "+rangeEnd;
          return false;
        }
      }
  
    } 
    return true;
 }
 
 save1201(){
    if(this.masterData.applycheck == "Y"){
        if(! this.validateCoat1DryFilm()){
          return
        }
      }

    if(this.jobId){
     var t = this.everslik1201List;
      var payload=  {everslik1201: this.everslik1201List, jobId:this.jobId}
      this.httpClient.post("everslik1201",payload).subscribe(res=>{
         this.sucess1201 = true;
         this.sucessMessage1201 = "Coating 1  Saved Successfully";
         
      })
    }else{
     this.error1201 = true;
     this.errorMessage1201 = "Please select Batch Number"
    }
 }

 saveCuring1201(){
    
    if(this.jobId){
     var t = this.everslikCuringList;
      var payload=  {flashCuring1201: this.everslikCuringList, jobId:this.jobId}
      this.httpClient.post("flashcuring1201",payload).subscribe(res=>{
         this.sucessCuring1201 = true;
         this.sucessMessageCuring1201 = "Flash Curing 1 Saved Successfully";
         
      })
    }else{
     this.errorCuring1201 = true;
     this.errorMessageCuring1201 = "Please select Batch Number"
    }
 }

 saveCuring2(){
    
    if(this.jobId){
   
      var payload=  {flashCuring1301: this.curing2List, jobId:this.jobId}
      this.httpClient.post("flashcuring1301",payload).subscribe(res=>{
        this.sucessCuring2 = true;
         this.sucessMessageCuring2 = "Curing 2 Saved Successfully";

        
         
      })
    }else{
        this.errorCuring2 = true;
        this.errorMessageCuring2 = "Please select Batch Number"
    
    }
 }

    validateCoat2DryFilm(){
      var val = this.masterData.topCoatThicknessRequired;
      if(val != null){
        var valArr = val.split("to");
        var rangeStart = valArr[0].trim();
        var rangeEnd = valArr[1].trim();
      
        for (let tempList of this.coating2List) {
          if(tempList['dryFlimTickness'] < Number(rangeStart) || tempList['dryFlimTickness'] > Number(rangeEnd) ){
            this.errorCoating2 = true;
            this.errorMessageCoating2 = "Dry Flim Thinckness Value should be between "+rangeStart + " and "+rangeEnd;
            return false;
          }
        }
    
      } 
      return true;
    }
  saveCoating2(){
    if(this.masterData.applycheck == "Y"){
        if(! this.validateCoat2DryFilm()){
            return
        }

        
    }

    if(this.jobId){
     
      var payload=  {everslik1301: this.coating2List, jobId:this.jobId}
      this.httpClient.post("everslik1301",payload).subscribe(res=>{
        this.sucessCoating2 = true;
        this.sucessMessageCoating2 = "Coating 2 Saved Successfully";
         
      })
    }else{
        this.errorCoating2 = true;
        this.errorMessageCoating2 = "Please select Batch Number"
    }
 }

 addNewRow1201(){

    if(this.jobId){
        let now =new Date();
        let latest_date =this.datepipe.transform(now, 'yyyy-MM-dd');
        this.everslik1201List.push({id:-1,date:latest_date,time:"",ambiantTemp:"",dewTemp:"",partTemp:"",humidity:"",coatingsys:this.coatingSysString,coatingsupplier:"",coatingbatch:"",mgfDate:"",expDate:"",stime:"",endtime:"",operationtime:"",dryFlimTickness:"",operator:""})   
    }else{
        this.error1201 = true;
        this.errorMessage1201 = "Please select Batch Number"
    }

    
 }
 addNewRowCuring1201(){
    if(this.jobId){
        let now =new Date();
        let latest_date =this.datepipe.transform(now, 'yyyy-MM-dd');
        this.everslikCuringList.push({id:-1, date:latest_date,time:"",ambientTemp:"",dewTemp:"",partTemp:"",humidity:"",ovenno:"",flashTemp:"",flashtStart:"",flashEnd:"",flashDuration:"",finalTemp:"",finalStart:"",finalEnd:"",finalDuration:"",operator:""})
    }else{
        this.errorCuring1201 = true;
        this.errorMessageCuring1201 = "Please select Batch Number"
    }

    
    
 }

 addNewRowCoating2(){
    if(this.jobId){
        let now =new Date();
        let latest_date =this.datepipe.transform(now, 'yyyy-MM-dd');
        this.coating2List.push({id:-1,date:latest_date,time:"",ambiantTemp:"",dewTemp:"",partTemp:"",humidity:"",coatingsys:this.coatingSysString,coatingsupplier:"",coatingbatch:"",mgfDate:"",expDate:"",stime:"",endtime:"",operationtime:"",dryFlimTickness:"",operator:""})
    }else{
        this.errorCoating2 = true;
        this.errorMessageCoating2 = "Please select Batch Number"
    }
    
}

addNewRowCuring2(){
    if(this.jobId){
        let now =new Date();
        let latest_date =this.datepipe.transform(now, 'yyyy-MM-dd');
      this.curing2List.push({id:-1, date:latest_date,time:"",ambientTemp:"",dewTemp:"",partTemp:"",humidity:"",ovenno:"",flashTemp:"",flashtStart:"",flashEnd:"",flashDuration:"",finalTemp:"",finalStart:"",finalEnd:"",finalDuration:"",operator:""})
    }else{
        this.errorCuring2 = true;
        this.errorMessageCuring2 = "Please select Batch Number"
    }
   
 }

 close(){
     this.error1201=false;
 }
 closeSuccess(){
     this.sucess1201=false;
 }

 closeCuring1201(){
    this.errorCuring1201=false;
}
closeSuccessCuring1201(){
    this.sucessCuring1201=false;
}

closeErrorCoating2(){
    this.errorCoating2=false;
}
closeSuccessCoating2(){
    this.sucessCoating2=false;
}

closeErrorCuring2(){
    this.errorCuring2=false;
}
closeSuccessCuring2(){
    this.sucessCuring2=false;
}
}
