import { CoatingModule } from './coating.module';

describe('CoatingModule', () => {
  let coatingModule: CoatingModule;

  beforeEach(() => {
    coatingModule = new CoatingModule();
  });

  it('should create an instance', () => {
    expect(coatingModule).toBeTruthy();
  });
});
