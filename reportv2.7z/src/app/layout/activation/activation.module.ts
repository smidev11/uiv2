import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivationRoutingModule } from './activation-routing.module';
import { ActivationComponent } from './activation.component';
import { PageHeaderModule } from './../../shared';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  imports: [CommonModule, ActivationRoutingModule, PageHeaderModule,NgbModule,FormsModule,HttpClientModule],
  declarations: [ActivationComponent]
})
export class ActivationModule { }







