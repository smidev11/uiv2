import { Component, OnInit, Optional,ViewChild } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Http, Response, Headers, RequestOptions, ResponseContentType, ResponseType } from '@angular/http';
import { deepEqual } from 'assert';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {saveAs } from "file-saver";


import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';




const states = ['Alabama', 'Alaska', 'American Samoa', 'Arizona', 'Arkansas', 'California', 'Colorado',
  'Connecticut', 'Delaware', 'District Of Columbia', 'Federated States Of Micronesia', 'Florida', 'Georgia',
  'Guam', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine',
  'Marshall Islands', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana',
  'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota',
  'Northern Mariana Islands', 'Ohio', 'Oklahoma', 'Oregon', 'Palau', 'Pennsylvania', 'Puerto Rico', 'Rhode Island',
  'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virgin Islands', 'Virginia',
  'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'];



//https://shekhargulati.com/2017/07/16/implementing-file-save-functionality-with-angular-4/
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public model: any;

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term => term.length < 1 ? []
        : states.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )
  

  jobList: Array<any> = [];

  TestReport(id){
  }
  
  exportReport(jobId):void
  {
   
    this.getFile("download?jobId="+jobId)
    .subscribe(response => 
      {
      let b:any = new Blob([response.blob()], { type: 'application/vnd.openxmlformats-officedocument.wordprocessin' });
      const contentDispositionHeader: string = response.headers.get('Content-Disposition');
      const parts: string[] = contentDispositionHeader.split(';');
      const filename = parts[1].split('=')[1];
      saveAs(b,filename)
      //var url= window.URL.createObjectURL(b);
        //window.open(url);
      //}
      });
  }
  
 
  public getFile(path: string):Observable<any>{
    let options = new RequestOptions({responseType: ResponseContentType.Blob});
    return this.httpn.get(path,options)
        .map((response: Response) => response)  ;
       
  }

  /*
exportReport(jobId) {
    debugger
    this.http.get("download").subscribe(res=>{
      //here you received the response of your post
      console.log(res);
      debugger
      //you can do asomething, like
      alert("Response got");
  })
    
    //const headers = new HttpHeaders();
   // headers.append('Accept', 'text/plain');
    this.http.get('download')
      .toPromise()
     .then(response => this.saveToFileSystem(response));
  }
  
  */

  /*
  private saveToFileSystem(response) {
    debugger
    const contentDispositionHeader: string = response.headers.get('Content-Disposition');
    const parts: string[] = contentDispositionHeader.split(';');
    const filename = parts[1].split('=')[1];
    const blob = new Blob([response._body], { type: 'text/plain' });
    saveAs(blob,filename)
    //saveAs(blob, filename);
  }
 */
  
  
  constructor(private http: HttpClient,private httpn:Http) { 
   // debugger
  }

  ngOnInit() {
    
    this.http.get("job").subscribe(res=>{
      let result= <any>res;
      //here you received the response of your post
      this.jobList = result
      console.log(result);
      
      //you can do asomething, like
      
  })
  }

}
