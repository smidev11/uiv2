import { HomeModule } from './home.module';

describe('FormModule', () => {
    let formModule: HomeModule;

    beforeEach(() => {
        formModule = new HomeModule();
    });

    it('should create an instance', () => {
        expect(formModule).toBeTruthy();
    });
});
