import { Component, OnInit } from '@angular/core';

import { routerTransition } from '../../router.animations';
import { HttpClient, HttpParams } from '@angular/common/http';
import * as $ from 'jquery';
// For autosuggest
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { DELEGATE_CTOR } from '@angular/core/src/reflection/reflection_capabilities';

@Component({
  selector: 'app-finalinsepection',
  templateUrl: './finalinsepection.component.html',
  styleUrls: ['./finalinsepection.component.css']
})
export class FinalinsepectionComponent implements OnInit {

  inspectionList=[]



  // For autosuggest start
  EMPLIST=[];
  jobList=[];
  public model: any;
  jobId:String;
  TCNumberList = []
  clientNameList=[]
 
  error:boolean;
  errorMessage;
  sucess:boolean;
  sucessMessage;
  // For autosuggest end
  editField: string;
  
 
 
  SelectedRowId: any = '';
  ShowEditTable :boolean = false;
  qualityInspector:string;
  dateInspector:string;
  batchId:string
  batchIdList:any=[]
 
  search = (text$: Observable<string>) =>
  text$.pipe(
    debounceTime(200),
    distinctUntilChanged(),
    map(term => term.length < 1 ? []
      : this.EMPLIST.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
  )
 
 
 updateList(id: number,property: string,event: any) {
    
    if(property == "endtime"){
       debugger
       var tempstarttime = this.inspectionList[id]['stime']
       var tempendtime = this.inspectionList[id]['endtime']
 
       var stime = this.getMinutes(tempstarttime);
       var etime = this.getMinutes(tempendtime)
       var val = (Number(etime) - Number(stime))
       var operational_time = " ";
       
       if(val < 0){
          operational_time = " "
       }else{
          
           if(val > 60){
               var totalmin = val % 60;
               var totalhr = (val/60);
               var strtotalhr = totalhr+"";
               if(strtotalhr.includes(".")){
                  strtotalhr = strtotalhr.split(".")[0]
               }
               operational_time = strtotalhr +" hr "+totalmin+" min"
               
           }else{
            operational_time = val+" min"
          }
       }
       this.inspectionList[id]["operationtime"] = operational_time;
      
    }
    
  }
 
  remove(id: any) {
    
    this.inspectionList.splice(id, 1);
  }
 
  
 
  changeValue(id: number, property: string, event: any) {
      
      this.inspectionList[id][property] = "";
      
  }
 

 
  getMinutes(time:string){
      debugger
      var res = time.split(":")
      var hr = res[0]
      var min = res[1];
      
      var startmin = (Number(hr) * 60)+parseInt(min)
      
      return startmin
      
  }
 
  constructor(private httpClient:HttpClient) {
     
  }
 
  ngOnInit() {
 
      this.httpClient.get("job").subscribe(res=>{
          let result= <any>res;
          this.jobList = result
          for(let j of this.jobList){
            this.batchIdList.push(j.batchId)
          }
          
      });
 
       //Get EMPList
       debugger
       this.httpClient.get("/api/util/emp").subscribe(res=>{
       let result= <any>res;
       this.EMPLIST = result
       
    })
  }
 
 
  
  Edit(value){
     
      this.SelectedRowId = value;
    
    }
 
 
    EditField(id: number,property: string){
      var propval = this.inspectionList[id][property]
      if(id==0){
          this.inspectionList.forEach(function (person) {
              person[property] = propval;
          }); 
      }
     
    }
 
  save(){
    
     if(this.jobId){
      
       var payload=  {finalInspection: this.inspectionList, jobId:this.jobId}
       this.httpClient.post("finalinpsection",payload).subscribe(res=>{
          this.sucess = true;
          this.sucessMessage = "Final Inspection Saved Successfully";
          
       })
     }else{
      this.error = true;
      this.errorMessage = "Please select Client Name"
     }
     
   
  }
 
  addNewRow(){
      this.inspectionList.push({id:-1, partIdentification:"",pcs:"",thickness_min:"",thickness_max:"",thickness_average:"",visualcontrol:"",curingtest:""})
  }
 
  close(){
      this.error=false;
  }
  closeSuccess(){
      this.sucess=false;
  }

  fetchData() {
       
    var selectedBatchJobId;
    for(let jobInfo of this.jobList){
        if(this.batchId == jobInfo.batchId){
            selectedBatchJobId = jobInfo.id;
            break;
        }
    }
    if(selectedBatchJobId){
        this.jobId =selectedBatchJobId
        this.httpClient.get("finalinpsection?jobId="+selectedBatchJobId).subscribe(res=>{
        let result= <any>res;
        debugger
        this.inspectionList = result;
        
        
        });
    }else{
        this.inspectionList=[];
    }
    
}

searchBatch = (text$: Observable<string>) =>
text$.pipe(
debounceTime(200),
distinctUntilChanged(),
map(term => term.length < 1 ? []
: this.batchIdList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
)

}
