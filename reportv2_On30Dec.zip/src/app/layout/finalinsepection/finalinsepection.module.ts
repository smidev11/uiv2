import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FinalinsepectionRoutingModule } from './finalinsepection-routing.module';
import { FinalinsepectionComponent } from './finalinsepection.component';
import { PageHeaderModule } from './../../shared';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    CommonModule,FinalinsepectionRoutingModule, PageHeaderModule,HttpClientModule,FormsModule,NgbModule
  ],
  declarations: [FinalinsepectionComponent]
})
export class FinalinsepectionModule { }
