import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



import { GritblastRoutingModule } from './gritblast-routing.module';
import { GritblastComponent } from './gritblast.component';
import { PageHeaderModule } from './../../shared';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    CommonModule,GritblastRoutingModule, PageHeaderModule,HttpClientModule,FormsModule,NgbModule
  ],
  declarations: [GritblastComponent]
})
export class GritblastModule { }
