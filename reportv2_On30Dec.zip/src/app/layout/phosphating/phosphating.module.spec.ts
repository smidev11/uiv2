import { PhosphatingModule } from './phosphating.module';

describe('PhosphatingModule', () => {
  let phosphatingModule: PhosphatingModule;

  beforeEach(() => {
    phosphatingModule = new PhosphatingModule();
  });

  it('should create an instance', () => {
    expect(phosphatingModule).toBeTruthy();
  });
});
