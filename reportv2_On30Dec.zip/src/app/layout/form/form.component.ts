import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DatePipe } from '@angular/common'
import { Observable } from 'rxjs/Observable';
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import { DELEGATE_CTOR } from '@angular/core/src/reflection/reflection_capabilities';

@Component({
    selector: 'app-form',
    templateUrl: './form.component.html',
    styleUrls: ['./form.component.scss'],
    animations: [routerTransition()]
})
export class FormComponent implements OnInit {
    
    registerForm: FormGroup;
    submitted = false;
   
   partsList: any = [];
   SelectedRowId: any = '';
   ShowEditTable :boolean = false;
   clientInfoList:any = [];
   clientList:any=[];
   empList:any=[];
   sucess: boolean;
   sucessMessage;
   searchBatchId:boolean;
   selectedBatchId:string;
   masterList:any=[]
   coatingSpecificationList:any=[]
   //genList:any=[];
    constructor(private formBuilder: FormBuilder, private http: HttpClient,public datepipe: DatePipe) {
        
    }
    
    Edit(value){
        
        this.SelectedRowId = value;
      
      }
      EditField(fieldVal){
      
      }
    ngOnInit() {
        
        let now =new Date();
        let latest_date =this.datepipe.transform(now, 'yyyy-MM-dd');
        
        this.registerForm = this.formBuilder.group({
            clientName: ['', Validators.required],
            batchId: ['', Validators.required],
            address: ['', Validators.required],
            date: [latest_date, Validators.required],
            pono: ['', Validators.nullValidator],
            endcustomer: ['', Validators.nullValidator],
            endCutomerPoLineItem: ['', Validators.nullValidator],
            //partno: ['', Validators.nullValidator],
           // serialno: ['', Validators.nullValidator],
            //heatno: ['', Validators.nullValidator],
           // heatlotno: ['', Validators.nullValidator],
            //qnt: ['', Validators.nullValidator],
            jobwo: ['', Validators.nullValidator],
            coatingspec: ['', Validators.nullValidator],
            coatingsys: ['', Validators.nullValidator],
            tcno: ['', Validators.nullValidator],
            desc: ['', Validators.nullValidator],
            nacecert: ['', Validators.nullValidator],
            maskrequ: ['', Validators.nullValidator],
            inspectorname:['', Validators.nullValidator],
            batch:['', Validators.nullValidator]
           
            //password: ['', [Validators.required, Validators.minLength(6)]]
        });


        this.http.get("/api/util/client").subscribe(res=>{
            let result= <any>res;
            //here you received the response of your post
           
            this.clientInfoList = result
            for(let j of this.clientInfoList){
                this.clientList.push(j.clientName)
            }
            console.log(result);
            
            //you can do asomething, like
            
        });

        //Get EMPList
        this.http.get("/api/util/emp").subscribe(res=>{
            let result= <any>res;
           //here you received the response of your post
            this.empList = result
            console.log(result);
        })

        this.http.get("/api/util/masterlist").subscribe(res=>{
          this.masterList = res;

          for(let specInfo of this.masterList){
            this.coatingSpecificationList.push(specInfo.customerSpecification)
        }
        });
    }

    get f() { return this.registerForm.controls; }
    
    save() {
        
        this.submitted = true;
        debugger
        // stop here if form is invalid
        //if (this.registerForm.invalid) {

            //return;
        //}

        //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value))
        
        
        if (this.registerForm.valid)
        {   
            var f = this.registerForm.value
            /*
            this.http.post("job",this.registerForm.value).subscribe(res=>{
                //here you received the response of your post
               this.sucess = true;
               this.sucessMessage = "Job Created Successfully";
               
            })
            */
            var payload=  {genRef: this.registerForm.value, partsList:this.partsList}
            this.http.post("job",payload).subscribe(res=>{
               this.sucess = true;
               this.sucessMessage = "Job Created Successfully";
               
            })
        }
        
        console.log("On sumbit")
    }

    searchClient = (text$: Observable<string>) =>
      
      text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term => term.length < 1 ? []
        : this.clientList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )
   

    searchCoatingSpec = (text$: Observable<string>) =>
      
      text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term => term.length < 1 ? []
        : this.coatingSpecificationList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )

     changeAddr(){
       
         var tempName = this.registerForm.controls.clientName.value;
       
          for(let cinfo of this.clientInfoList){
             if(tempName == cinfo.clientName){
              this.registerForm.controls['address'].setValue(cinfo.clientAddress);
             }
       }
    //    console.log(this.f.clientName)
    }

    searchEmp = (text$: Observable<string>) =>
      text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term => term.length < 1 ? []
        : this.empList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )
    
    closeSuccess() {
        this.sucess = false;
      }

      addNewRow(){
        this.partsList.push({id:-1, partno:"",serialno:"",qnt:" ",heatno:" ",heatlotno:" "})
       
    }
    batchNew(){
        
        let now =new Date();
        let latest_date =this.datepipe.transform(now, 'yyyy-MM-dd');

        this.registerForm.controls['clientName'].setValue("");
        this.registerForm.controls['address'].setValue("");
        this.registerForm.controls['date'].setValue(latest_date);
        this.registerForm.controls['pono'].setValue("");
        this.registerForm.controls['endcustomer'].setValue("");
        this.registerForm.controls['endCutomerPoLineItem'].setValue("");
        this.registerForm.controls['jobwo'].setValue("");
        this.registerForm.controls['coatingspec'].setValue("");
        this.registerForm.controls['coatingsys'].setValue("");
        this.registerForm.controls['tcno'].setValue("");

        this.registerForm.controls['desc'].setValue("");
        this.registerForm.controls['nacecert'].setValue("");
        this.registerForm.controls['maskrequ'].setValue("");
        this.registerForm.controls['inspectorname'].setValue("");

        this.partsList =[];

        this.searchBatchId = false
        this.http.get("batchid").subscribe(res=>{
            this.registerForm.controls['batchId'].setValue(res);
          
           
        })

        
    }
    
    fetchMaterList(){
        debugger
        var spec = this.registerForm.controls.coatingspec.value;
        for(let specInfo of this.masterList){
            if(spec == specInfo.customerSpecification){
                this.registerForm.controls['coatingsys'].setValue(specInfo.coatingSystem);
                this.registerForm.controls['tcno'].setValue(specInfo.tcno);
            }
        }

    }

    fetchJobs(event: any) {
       
        var batchId = this.registerForm.controls.batchId.value;
        this.http.get("batchById?batchId="+batchId).subscribe(res=>{
            let result= <any>res;
            this.partsList = result.partsList;
            var genRefValue = result.genRef;
            this.registerForm.controls['clientName'].setValue(genRefValue.clientName);
            this.registerForm.controls['address'].setValue(genRefValue.address);
            this.registerForm.controls['date'].setValue(genRefValue.date);
            this.registerForm.controls['pono'].setValue(genRefValue.pono);
            this.registerForm.controls['endcustomer'].setValue(genRefValue.endcustomer);
            this.registerForm.controls['endCutomerPoLineItem'].setValue(genRefValue.endCutomerPoLineItem);
            this.registerForm.controls['jobwo'].setValue(genRefValue.jobwo);
            this.registerForm.controls['coatingspec'].setValue(genRefValue.coatingspec);
            this.registerForm.controls['coatingsys'].setValue(genRefValue.coatingsys);
            this.registerForm.controls['tcno'].setValue(genRefValue.tcno);

            this.registerForm.controls['desc'].setValue(genRefValue.desc);
            this.registerForm.controls['nacecert'].setValue(genRefValue.nacecert);
            this.registerForm.controls['maskrequ'].setValue(genRefValue.maskrequ);
            this.registerForm.controls['inspectorname'].setValue(genRefValue.inspectorname);

            
            
            

            
        });
    }

    batchSearch(){
        this.searchBatchId = true
        this.registerForm.controls['batchId'].setValue("");
    }
}
