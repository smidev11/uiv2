import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            { path: '', redirectTo: 'home', pathMatch: 'prefix' },
            { path: 'home', loadChildren: './home/home.module#HomeModule' },
            { path: 'degreasing', loadChildren: './tables/tables.module#TablesModule' },
            { path: 'genref', loadChildren: './form/form.module#FormModule' },
            { path: 'gritblast', loadChildren: './gritblast/gritblast.module#GritblastModule' },
            { path: 'activation', loadChildren: './activation/activation.module#ActivationModule' },
            { path: 'phosphating', loadChildren: './phosphating/phosphating.module#PhosphatingModule' },
            { path: 'coating', loadChildren: './coating/coating.module#CoatingModule' },
            { path: 'finalinsepection',loadChildren: './finalinsepection/finalinsepection.module#FinalinsepectionModule' },
            { path: 'pkgdispatch',loadChildren: './pkgdispatch/pkgdispatch.module#PkgdispatchModule' },
            { path: 'nonconformity', loadChildren: './nonconformity/nonconformity.module#NonconformityModule' },
            { path: 'inspafterreparation',loadChildren: './inspafterreparation/inspafterreparation.module#InspafterreparationModule' }
        ]   
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule {}
