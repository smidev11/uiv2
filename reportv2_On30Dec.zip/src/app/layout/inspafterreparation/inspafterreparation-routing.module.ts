import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InspafterreparationComponent } from './inspafterreparation.component';

const routes: Routes = [
    {
        path: '', component: InspafterreparationComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class InspafterreparationRoutingModule {
}
