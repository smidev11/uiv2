import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { InspafterreparationRoutingModule } from './inspafterreparation-routing.module';
import { InspafterreparationComponent } from './inspafterreparation.component';
import { PageHeaderModule } from './../../shared';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    CommonModule,InspafterreparationRoutingModule, PageHeaderModule,HttpClientModule,FormsModule,NgbModule
  ],
  declarations: [InspafterreparationComponent]
})
export class InspafterreparationModule { }
