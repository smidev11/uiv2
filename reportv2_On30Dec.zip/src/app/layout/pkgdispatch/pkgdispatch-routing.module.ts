import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PkgdispatchComponent } from './pkgdispatch.component';

const routes: Routes = [
    {
        path: '', component: PkgdispatchComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class PkgdispatchRoutingModule {
}
