import { NonconformityModule } from './nonconformity.module';

describe('NonconformityModule', () => {
  let nonconformityModule: NonconformityModule;

  beforeEach(() => {
    nonconformityModule = new NonconformityModule();
  });

  it('should create an instance', () => {
    expect(nonconformityModule).toBeTruthy();
  });
});
