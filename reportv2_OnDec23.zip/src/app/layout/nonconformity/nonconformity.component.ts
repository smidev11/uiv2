import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nonconformity',
  templateUrl: './nonconformity.component.html',
  styleUrls: ['./nonconformity.component.css']
})
export class NonconformityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
