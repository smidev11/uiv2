import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NonconformityComponent } from './nonconformity.component';

describe('NonconformityComponent', () => {
  let component: NonconformityComponent;
  let fixture: ComponentFixture<NonconformityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NonconformityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NonconformityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
