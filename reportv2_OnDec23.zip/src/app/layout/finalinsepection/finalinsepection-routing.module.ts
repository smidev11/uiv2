import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FinalinsepectionComponent } from './finalinsepection.component';

const routes: Routes = [
    {
        path: '', component: FinalinsepectionComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class FinalinsepectionRoutingModule {
}
