import { Component, OnInit } from '@angular/core';


import { routerTransition } from '../../router.animations';
import { HttpClient, HttpParams } from '@angular/common/http';
import * as $ from 'jquery';
// For autosuggest
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { DELEGATE_CTOR } from '@angular/core/src/reflection/reflection_capabilities';
import {NgbDateStruct, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-coating',
  templateUrl: './coating.component.html',
  styleUrls: ['./coating.component.css']
})
export class CoatingComponent implements OnInit {
 EMPLIST=[];
 jobList=[];
 jobId:String;

 error1201:boolean;
 errorMessage1201;
 sucess1201:boolean;
 sucessMessage1201;
 everslik1201List: Array<any> = [ ];
 SelectedRowId: any = '';
 //model: NgbDateStruct


 errorCuring1201:boolean;
 errorMessageCuring1201;
 sucessCuring1201:boolean;
 sucessMessageCuring1201;
 everslikCuringList: Array<any> = [ ];


 errorCuring1301:boolean;
 errorMessageCuring1301;
 sucessCuring1301:boolean;
 sucessMessageCuring1301;
 everslikCuring1301List: Array<any> = [ ];



 errorSlik1301:boolean;
 errorSlik1301Message;
 sucessSlik1301:boolean;
 sucessMessageSlik1301;
 everSlik1301List: Array<any> = [ ];

 search = (text$: Observable<string>) =>
 text$.pipe(
   debounceTime(200),
   distinctUntilChanged(),
   map(term => term.length < 1 ? []
     : this.EMPLIST.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
 )


 

  updateList(id: number,property: string,event: any) {
   
   if(property == "endtime"){
      debugger
      var tempstarttime = this.everslik1201List[id]['stime']
      var tempendtime = this.everslik1201List[id]['endtime']

      var stime = this.getMinutes(tempstarttime);
      var etime = this.getMinutes(tempendtime)
      var val = (Number(etime) - Number(stime))
      var operational_time = " ";
      
      if(val < 0){
         operational_time = " "
      }else{
         
          if(val > 60){
              var totalmin = val % 60;
              var totalhr = (val/60);
              var strtotalhr = totalhr+"";
              if(strtotalhr.includes(".")){
                 strtotalhr = strtotalhr.split(".")[0]
              }
              operational_time = strtotalhr +" hr "+totalmin+" min"
              
          }
      }
      this.everslik1201List[id]["operationtime"] = operational_time;
     
   }
   
 }

 remove1201(id: any) {
   this.everslik1201List.splice(id, 1);
 }

 remove1301(id: any) {
    this.everSlik1301List.splice(id, 1);
  }
  
 
 removecuring1201(id: any){
     this.everslikCuringList.slice(id,1);
 }
 
 removecuring1301(id: any){
    this.everslikCuring1301List.slice(id,1);
}
 
 getMinutes(time:string){
     debugger
     var res = time.split(":")
     var hr = res[0]
     var min = res[1];
     var startmin = (Number(hr) * 60)+parseInt(min)
     return startmin
     
 }

 constructor(private httpClient:HttpClient) {
    
 }

 ngOnInit() {

     this.httpClient.get("job").subscribe(res=>{
         let result= <any>res;
         this.jobList = result
     });

      this.httpClient.get("/api/util/emp").subscribe(res=>{
      let result= <any>res;
      this.EMPLIST = result
      
   })

   this.everslik1201List.push({id:-1, stime:"",endtime:"",product:" ",qnt:" ",batch:"",mgfDate:"",expDate:"",operator:" ",operationtime:""})
 }

 
 fetchClientDetails(selectedJobId: any) {
     
     this.jobId = selectedJobId;
     this.httpClient.get("everslik1201?jobId="+selectedJobId).subscribe(res=>{
         let result= <any>res;
         this.everslik1201List = result;
     });

     this.httpClient.get("flashcuring1201?jobId="+selectedJobId).subscribe(res=>{
        let result= <any>res;
        this.everslikCuringList = result;
    });

    this.httpClient.get("everslik1301?jobId="+selectedJobId).subscribe(res=>{
        let result= <any>res;
        this.everSlik1301List = result;
    });

    this.httpClient.get("flashcuring1301?jobId="+selectedJobId).subscribe(res=>{
        let result= <any>res;
        this.everslikCuring1301List = result;
    });
 }

 Edit(value){
    
    this.SelectedRowId = value;
  
  }

 
 save1201(){
   
    if(this.jobId){
     var t = this.everslik1201List;
      var payload=  {everslik1201: this.everslik1201List, jobId:this.jobId}
      this.httpClient.post("everslik1201",payload).subscribe(res=>{
         this.sucess1201 = true;
         this.sucessMessage1201 = "EverSlik 1201  Saved Successfully";
         
      })
    }else{
     this.error1201 = true;
     this.errorMessage1201 = "Please select Client Name"
    }
 }

 saveCuring1201(){
    
    if(this.jobId){
     var t = this.everslikCuringList;
      var payload=  {flashCuring1201: this.everslikCuringList, jobId:this.jobId}
      this.httpClient.post("flashcuring1201",payload).subscribe(res=>{
         this.sucessCuring1201 = true;
         this.sucessMessageCuring1201 = "Flash Curing Of EverSlik 1201  Saved Successfully";
         
      })
    }else{
     this.errorCuring1201 = true;
     this.errorMessageCuring1201 = "Please select Client Name"
    }
 }

 saveCuring1301(){
    
    if(this.jobId){
     var t = this.everslikCuring1301List;
      var payload=  {flashCuring1301: this.everslikCuring1301List, jobId:this.jobId}
      this.httpClient.post("flashcuring1301",payload).subscribe(res=>{
         this.sucessCuring1301 = true;
         this.sucessMessageCuring1301 = "Flash Curing Of EverSlik 1301  Saved Successfully";
         
      })
    }else{
     this.errorCuring1301 = true;
     this.errorMessageCuring1301 = "Please select Client Name"
    }
 }

 save1301(){
   
    if(this.jobId){
     var t = this.everSlik1301List;
      var payload=  {everslik1301: this.everSlik1301List, jobId:this.jobId}
      this.httpClient.post("everslik1301",payload).subscribe(res=>{
         this.sucessSlik1301 = true;
         this.sucessMessageSlik1301 = "EverSlik 1301  Saved Successfully";
         
      })
    }else{
     this.errorSlik1301 = true;
     this.errorSlik1301Message = "Please select Client Name"
    }
 }

 addNewRow1201(){
     this.everslik1201List.push({id:-1, stime:"",endtime:"",product:" ",qnt:" ",batch:"",mgfDate:"",expDate:"",operator:" ",operationtime:""})
 }
 addNewRowCuring1201(){
    this.everslikCuringList.push({id:-1, stime:"",endtime:"",product:" ",qnt:" ",drying_ambient:"",drying_temp_20_40_min:"",curing_temp_132_148_min:"",curing_temp_20_40_2:"",operator:" ",operationtime:""})
 }

 addNewRow1301(){
    this.everSlik1301List.push({id:-1, stime:"",endtime:"",product:" ",qnt:" ",batch:"",mgfDate:"",expDate:"",operator:" ",operationtime:""})
}

addNewRowCuring1301(){
    this.everslikCuring1301List.push({id:-1, stime:"",endtime:"",product:" ",qnt:" ",drying_ambient:"",drying_temp_20_40_min:"",curing_temp_132_148_min:"",curing_temp_20_40_2:"",operator:" ",operationtime:""})
 }

 close(){
     this.error1201=false;
 }
 closeSuccess(){
     this.sucess1201=false;
 }

 closeCuring1201(){
    this.errorCuring1201=false;
}
closeSuccessCuring1201(){
    this.sucessMessageCuring1201=false;
}

close1301(){
    this.errorSlik1301=false;
}
closeSuccess1301(){
    this.sucessSlik1301=false;
}

closeCuring1301(){
    this.errorCuring1301=false;
}
closeSuccessCuring1301(){
    this.sucessMessageCuring1301=false;
}
}
