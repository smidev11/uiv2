import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { PkgdispatchRoutingModule } from './pkgdispatch-routing.module';
import { PkgdispatchComponent } from './pkgdispatch.component';
import { PageHeaderModule } from './../../shared';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    CommonModule,PkgdispatchRoutingModule, PageHeaderModule,HttpClientModule,FormsModule,NgbModule
  ],
  declarations: [PkgdispatchComponent]
})
export class PkgdispatchModule { }
