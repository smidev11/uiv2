import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { HttpClient, HttpParams } from '@angular/common/http';
import * as $ from 'jquery';
// For autosuggest
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { DELEGATE_CTOR } from '@angular/core/src/reflection/reflection_capabilities';

@Component({
  selector: 'app-phosphating',
  templateUrl: './phosphating.component.html',
  styleUrls: ['./phosphating.component.css']
})
export class PhosphatingComponent implements OnInit {


 // For autosuggest start
 EMPLIST=[];
 jobList=[];
 public model: any;
 jobId:String;
 TCNumberList = []
 clientNameList=[]
 selected_tc_no;
 selected_client;
 error:boolean;
 errorMessage;
 sucess:boolean;
 sucessMessage;
 // For autosuggest end
 editField: string;
 phosphatingList: Array<any> = [ ];

 TableData: any = [];
 SelectedRowId: any = '';
 ShowEditTable :boolean = false;
 
 searchTC = (text$: Observable<string>) =>
 text$.pipe(
   debounceTime(200),
   distinctUntilChanged(),
   map(term => term.length < 1 ? []
     : this.TCNumberList.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
 )

 search = (text$: Observable<string>) =>
 text$.pipe(
   debounceTime(200),
   distinctUntilChanged(),
   map(term => term.length < 1 ? []
     : this.EMPLIST.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
 )


 

  updateList(id: number,property: string,event: any) {
   
   if(property == "endtime"){
      debugger
      var tempstarttime = this.phosphatingList[id]['stime']
      var tempendtime = this.phosphatingList[id]['endtime']

      var stime = this.getMinutes(tempstarttime);
      var etime = this.getMinutes(tempendtime)
      var val = (Number(etime) - Number(stime))
      var operational_time = " ";
      
      if(val < 0){
         operational_time = " "
      }else{
         
          if(val > 60){
              var totalmin = val % 60;
              var totalhr = (val/60);
              var strtotalhr = totalhr+"";
              if(strtotalhr.includes(".")){
                 strtotalhr = strtotalhr.split(".")[0]
              }
              operational_time = strtotalhr +" hr "+totalmin+" min"
              
          }
      }
      this.phosphatingList[id]["operationtime"] = operational_time;
     
   }
   if (property == "temp") {
    debugger
    if (Number(this.phosphatingList[id]['temp']) > 95 || Number(this.phosphatingList[id]['temp']) < 90) {
        this.error = true;
        this.errorMessage = "Enter the value between 90 to 95";
        
      return false
    }
  } else {
    console.log("remove no match")
  }

   
 }

 remove(id: any) {
   
   this.phosphatingList.splice(id, 1);
 }

 

 changeValue(id: number, property: string, event: any) {
     
     this.phosphatingList[id][property] = "";
     
 }

 
 jobselect(jobid){
     this.jobId = jobid;
     this.httpClient.get("gritblast?jobId="+jobid).subscribe(res=>{
         let result= <any>res;
         
         console.log(result);
         this.phosphatingList = result;
         //you can do asomething, like
         
     });
 }

 getMinutes(time:string){
     debugger
     var res = time.split(":")
     var hr = res[0]
     var min = res[1];
     
     var startmin = (Number(hr) * 60)+parseInt(min)
     
     return startmin
     
 }

 constructor(private httpClient:HttpClient) {
    
 }

 ngOnInit() {

     this.httpClient.get("job").subscribe(res=>{
         let result= <any>res;
         this.jobList = result
         for(let j of this.jobList){
             this.TCNumberList.push(j.tcno)
         }
         
     });

      //Get EMPList
      debugger
      this.httpClient.get("/api/util/emp").subscribe(res=>{
      let result= <any>res;
      this.EMPLIST = result
      
   })
 }

 selectedOptionTC(){
     debugger
     for(let j of this.jobList){
         console.log(j.tcno);
         
         if(this.selected_tc_no == j.tcno){
             this.selected_client = j.clientName;
         }
     }
 }

 selectedOptionClient(){
     console.log(this.selected_client);
 }

 onOptionsSelected(event){
 
     console.log(event);
 }

 fetchClientDetails(selectedJobId: any) {
     
     this.jobId = selectedJobId;
     this.httpClient.get("phosphating?jobId="+selectedJobId).subscribe(res=>{
         let result= <any>res;
         this.phosphatingList = result;
     });
 }
 Edit(value){
    
     this.SelectedRowId = value;
   
   }


   EditField(id: number,property: string){
     var propval = this.phosphatingList[id][property]
     if(id==0){
         this.phosphatingList.forEach(function (person) {
             person[property] = propval;
         }); 
     }
    
   }

 save(){
   
    if(this.jobId){
     var t = this.phosphatingList;
      var payload=  {phosphating: this.phosphatingList, jobId:this.jobId}
      this.httpClient.post("phosphating",payload).subscribe(res=>{
         this.sucess = true;
         this.sucessMessage = "Phosphating Saved Successfully";
         
      })
    }else{
     this.error = true;
     this.errorMessage = "Please select Client Name"
    }
    
  
 }

 addNewRow(){
     this.phosphatingList.push({id:-1, stime:"",endtime:"",product:" ",qnt:" ",operator:" ",operationtime:""})
 }

 close(){
     this.error=false;
 }
 closeSuccess(){
     this.sucess=false;
 }

}
