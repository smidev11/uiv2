import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhosphatingComponent } from './phosphating.component';

describe('PhosphatingComponent', () => {
  let component: PhosphatingComponent;
  let fixture: ComponentFixture<PhosphatingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhosphatingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhosphatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
