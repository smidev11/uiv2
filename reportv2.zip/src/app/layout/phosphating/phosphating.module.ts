import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { PhosphatingRoutingModule } from './phosphating-routing.module';
import { PhosphatingComponent } from './phosphating.component';
import { PageHeaderModule } from './../../shared';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    CommonModule,PhosphatingRoutingModule, PageHeaderModule,HttpClientModule,FormsModule,NgbModule
  ],
  declarations: [PhosphatingComponent]
})
export class PhosphatingModule { }
